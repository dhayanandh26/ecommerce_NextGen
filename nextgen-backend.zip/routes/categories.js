/**
 * Categories Routes
 * GET  /api/categories       — list all
 * GET  /api/categories/:id   — get one
 * POST /api/categories       — create (admin)
 * PUT  /api/categories/:id   — update (admin)
 */

const catRouter = require('express').Router();
const { supabase, supabaseAdmin } = require('../config/supabase');
const { protect, adminOnly }      = require('../middleware/auth');
const { asyncHandler }            = require('../middleware/errorHandler');

catRouter.get('/', asyncHandler(async (req, res) => {
  const { data, error } = await supabase
    .from('categories')
    .select('*, products(count)')
    .order('category_id');
  if (error) throw error;
  res.json({ success: true, categories: data });
}));

catRouter.get('/:id', asyncHandler(async (req, res) => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('category_id', req.params.id)
    .single();
  if (error || !data) {
    const err = new Error('Category not found'); err.statusCode = 404; throw err;
  }
  res.json({ success: true, category: data });
}));

catRouter.post('/', protect, adminOnly, asyncHandler(async (req, res) => {
  const { name, description } = req.body;
  if (!name) { const err = new Error('Name required'); err.statusCode = 400; throw err; }
  const { data, error } = await supabaseAdmin
    .from('categories').insert({ name, description }).select().single();
  if (error) throw error;
  res.status(201).json({ success: true, category: data });
}));

catRouter.put('/:id', protect, adminOnly, asyncHandler(async (req, res) => {
  const { name, description } = req.body;
  const { data, error } = await supabaseAdmin
    .from('categories').update({ name, description })
    .eq('category_id', req.params.id).select().single();
  if (error) throw error;
  res.json({ success: true, category: data });
}));

module.exports = catRouter;

/**
 * Dashboard / Analytics Routes (Admin only)
 * GET /api/dashboard          — summary stats
 * GET /api/dashboard/revenue  — revenue by day/month
 * GET /api/dashboard/products — top selling products
 * GET /api/dashboard/orders   — recent orders
 */
const router = require('express').Router();
const { supabaseAdmin } = require('../config/supabase');
const { protect, adminOnly } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

router.use(protect, adminOnly);

/* Summary stats */
router.get('/', asyncHandler(async (req, res) => {
  const db = supabaseAdmin;

  const [
    { count: totalProducts },
    { count: totalOrders },
    { count: totalCustomers },
    { data: revenueData },
    { data: statusData },
  ] = await Promise.all([
    db.from('products').select('*', { count: 'exact', head: true }).eq('is_active', true),
    db.from('orders').select('*', { count: 'exact', head: true }),
    db.from('customers').select('*', { count: 'exact', head: true }),
    db.from('orders').select('total_amount').eq('status', 'delivered'),
    db.from('orders').select('status'),
  ]);

  const totalRevenue = (revenueData || []).reduce((s, o) => s + parseFloat(o.total_amount), 0);
  const statusCounts = (statusData || []).reduce((acc, o) => {
    acc[o.status] = (acc[o.status] || 0) + 1;
    return acc;
  }, {});

  res.json({
    success: true,
    stats: {
      total_products : totalProducts,
      total_orders   : totalOrders,
      total_customers: totalCustomers,
      total_revenue  : Math.round(totalRevenue * 100) / 100,
      orders_by_status: statusCounts,
    },
  });
}));

/* Recent orders */
router.get('/orders', asyncHandler(async (req, res) => {
  const limit = Math.min(50, parseInt(req.query.limit || 10));
  const { data, error } = await supabaseAdmin
    .from('orders')
    .select('order_id, total_amount, status, created_at, customers(first_name,last_name,email)')
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  res.json({ success: true, orders: data });
}));

/* Top selling products */
router.get('/products', asyncHandler(async (req, res) => {
  const { data, error } = await supabaseAdmin
    .from('order_items')
    .select('product_id, quantity, products(product_id,name,brand,price,image_url)')
    .order('quantity', { ascending: false })
    .limit(50);

  if (error) throw error;

  // Aggregate by product
  const map = {};
  (data || []).forEach(item => {
    const id = item.product_id;
    if (!map[id]) map[id] = { ...item.products, units_sold: 0, revenue: 0 };
    map[id].units_sold += item.quantity;
    map[id].revenue    += item.quantity * parseFloat(item.products?.price || 0);
  });

  const top = Object.values(map)
    .sort((a, b) => b.units_sold - a.units_sold)
    .slice(0, 10);

  res.json({ success: true, products: top });
}));

module.exports = router;

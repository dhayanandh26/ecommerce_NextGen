/**
 * Payments Routes
 * GET    /api/payments            — list (admin)
 * GET    /api/payments/:id        — get one
 * PATCH  /api/payments/:id/status — update status (admin)
 */
const payRouter = require('express').Router();
const { supabase, supabaseAdmin } = require('../config/supabase');
const { protect, adminOnly }      = require('../middleware/auth');
const { asyncHandler }            = require('../middleware/errorHandler');

payRouter.get('/', protect, adminOnly, asyncHandler(async (req, res) => {
  const page  = Math.max(1, parseInt(req.query.page  || 1));
  const limit = Math.min(100, parseInt(req.query.limit || 20));
  const from  = (page - 1) * limit;

  const { data, error, count } = await supabaseAdmin
    .from('payments')
    .select('*, orders(order_id, total_amount, status, customers(first_name,last_name,email))', { count: 'exact' })
    .range(from, from + limit - 1)
    .order('created_at', { ascending: false });

  if (error) throw error;
  res.json({ success: true, page, limit, total: count, payments: data });
}));

payRouter.get('/:id', protect, asyncHandler(async (req, res) => {
  const { data, error } = await supabase
    .from('payments').select('*').eq('payment_id', req.params.id).single();
  if (error || !data) {
    const err = new Error('Payment not found'); err.statusCode = 404; throw err;
  }
  res.json({ success: true, payment: data });
}));

payRouter.patch('/:id/status', protect, adminOnly, asyncHandler(async (req, res) => {
  const { status } = req.body;
  const valid = ['pending','completed','failed','refunded'];
  if (!valid.includes(status)) {
    const err = new Error(`Status must be one of: ${valid.join(', ')}`);
    err.statusCode = 400; throw err;
  }
  const { data, error } = await supabaseAdmin
    .from('payments').update({ status })
    .eq('payment_id', req.params.id).select().single();
  if (error) throw error;
  res.json({ success: true, payment: data });
}));

module.exports = payRouter;

/**
 * Customers Routes
 */
const custRouter = require('express').Router();
const { supabase, supabaseAdmin } = require('../config/supabase');
const { protect, adminOnly }      = require('../middleware/auth');
const { asyncHandler }            = require('../middleware/errorHandler');

// GET /api/customers — admin only
custRouter.get('/', protect, adminOnly, asyncHandler(async (req, res) => {
  const page  = Math.max(1, parseInt(req.query.page  || 1));
  const limit = Math.min(100, parseInt(req.query.limit || 20));
  const from  = (page - 1) * limit;

  const { data, error, count } = await supabaseAdmin
    .from('customers')
    .select('*, orders(count)', { count: 'exact' })
    .range(from, from + limit - 1)
    .order('created_at', { ascending: false });

  if (error) throw error;
  res.json({ success: true, page, limit, total: count, customers: data });
}));

// GET /api/customers/:id
custRouter.get('/:id', protect, asyncHandler(async (req, res) => {
  const { data, error } = await supabase
    .from('customers').select('*').eq('customer_id', req.params.id).single();
  if (error || !data) {
    const err = new Error('Customer not found'); err.statusCode = 404; throw err;
  }
  res.json({ success: true, customer: data });
}));

// PATCH /api/customers/:id — update own profile
custRouter.patch('/:id', protect, asyncHandler(async (req, res) => {
  const allowed = ['first_name','last_name','phone','address','city'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

  const { data, error } = await supabase
    .from('customers').update(updates)
    .eq('customer_id', req.params.id).select().single();
  if (error) throw error;
  res.json({ success: true, customer: data });
}));

module.exports = custRouter;

/**
 * NextGen Store API — Integration Tests
 * Run: npm test
 */

const request = require('supertest');
const app     = require('../server');

// ── Test helpers ──────────────────────────────────────────────
const BASE = '/api';
let authToken  = '';
let testOrderId = null;

// ── PRODUCTS ─────────────────────────────────────────────────
describe('Products', () => {
  test('GET /api/products — returns list', async () => {
    const res = await request(app).get(`${BASE}/products`);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(Array.isArray(res.body.products)).toBe(true);
  });

  test('GET /api/products?category=Electronics', async () => {
    const res = await request(app)
      .get(`${BASE}/products?category=Electronics`);
    expect(res.status).toBe(200);
    expect(res.body.products.every(p => p.category_name === 'Electronics')).toBe(true);
  });

  test('GET /api/products?sort=price_asc — sorted correctly', async () => {
    const res = await request(app)
      .get(`${BASE}/products?sort=price_asc&limit=5`);
    expect(res.status).toBe(200);
    const prices = res.body.products.map(p => p.price);
    for (let i = 1; i < prices.length; i++) {
      expect(prices[i]).toBeGreaterThanOrEqual(prices[i - 1]);
    }
  });

  test('GET /api/products?search=samsung', async () => {
    const res = await request(app).get(`${BASE}/products?search=samsung`);
    expect(res.status).toBe(200);
  });

  test('GET /api/products/:id — valid product', async () => {
    const res = await request(app).get(`${BASE}/products/1`);
    expect(res.status).toBe(200);
    expect(res.body.product.product_id).toBe(1);
  });

  test('GET /api/products/:id — invalid product returns 404', async () => {
    const res = await request(app).get(`${BASE}/products/99999`);
    expect(res.status).toBe(404);
  });

  test('GET /api/products/:id/related', async () => {
    const res = await request(app).get(`${BASE}/products/1/related`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.products)).toBe(true);
  });

  test('POST /api/products — requires auth', async () => {
    const res = await request(app)
      .post(`${BASE}/products`)
      .send({ name: 'Test Product', price: 999, category_id: 1 });
    expect(res.status).toBe(401);
  });
});

// ── CATEGORIES ───────────────────────────────────────────────
describe('Categories', () => {
  test('GET /api/categories — returns all', async () => {
    const res = await request(app).get(`${BASE}/categories`);
    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.categories.length).toBeGreaterThan(0);
  });

  test('GET /api/categories/:id', async () => {
    const res = await request(app).get(`${BASE}/categories/1`);
    expect(res.status).toBe(200);
    expect(res.body.category.category_id).toBe(1);
  });

  test('GET /api/categories/99999 — returns 404', async () => {
    const res = await request(app).get(`${BASE}/categories/99999`);
    expect(res.status).toBe(404);
  });
});

// ── ORDERS ───────────────────────────────────────────────────
describe('Orders', () => {
  test('POST /api/orders — missing fields returns 422', async () => {
    const res = await request(app)
      .post(`${BASE}/orders`)
      .send({ items: [] });
    expect([400, 422]).toContain(res.status);
  });

  test('POST /api/orders — valid guest order', async () => {
    const res = await request(app)
      .post(`${BASE}/orders`)
      .send({
        customer: { first_name: 'Test', last_name: 'User', phone: '9876543210' },
        shipping_address: '12, Anna Nagar',
        city: 'Chennai', state: 'Tamil Nadu', pin: '600040',
        items: [{ product_id: 1, quantity: 1 }],
        payment_method: 'cash_on_delivery',
      });

    // In test env without real Supabase, this may return 500
    // With real Supabase it should be 201
    if (res.status === 201) {
      expect(res.body.success).toBe(true);
      expect(res.body.order_id).toMatch(/^NGS-/);
      testOrderId = res.body.db_order_id;
    } else {
      // Accept failure gracefully in test env without DB
      expect([400, 500]).toContain(res.status);
    }
  });

  test('GET /api/orders — requires auth', async () => {
    const res = await request(app).get(`${BASE}/orders`);
    expect(res.status).toBe(401);
  });
});

// ── AUTH ─────────────────────────────────────────────────────
describe('Auth', () => {
  test('POST /api/auth/login — invalid credentials', async () => {
    const res = await request(app)
      .post(`${BASE}/auth/login`)
      .send({ email: 'notreal@test.com', password: 'wrongpassword' });
    expect([400, 401]).toContain(res.status);
  });

  test('POST /api/auth/login — missing email returns 422', async () => {
    const res = await request(app)
      .post(`${BASE}/auth/login`)
      .send({ password: 'testpass123' });
    expect(res.status).toBe(422);
  });

  test('GET /api/auth/me — requires auth', async () => {
    const res = await request(app).get(`${BASE}/auth/me`);
    expect(res.status).toBe(401);
  });

  test('POST /api/auth/refresh — missing token returns 400', async () => {
    const res = await request(app).post(`${BASE}/auth/refresh`).send({});
    expect(res.status).toBe(400);
  });
});

// ── HEALTH ───────────────────────────────────────────────────
describe('Health', () => {
  test('GET / — returns status', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('online');
  });

  test('GET /api — returns endpoints', async () => {
    const res = await request(app).get('/api');
    expect(res.status).toBe(200);
    expect(res.body.endpoints).toBeDefined();
  });

  test('GET /not-found — returns 404', async () => {
    const res = await request(app).get('/this-does-not-exist');
    expect(res.status).toBe(404);
  });
});

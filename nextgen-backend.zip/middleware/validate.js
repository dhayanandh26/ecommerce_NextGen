/**
 * Request validation helpers
 * Uses express-validator
 */

const { body, param, query, validationResult } = require('express-validator');

/* Run validation — send 422 if any errors */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error  : 'Validation failed',
      details: errors.array().map(e => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

/* ── Auth validators ─────────────────────────── */
const signupRules = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters'),
  body('first_name').trim().notEmpty().withMessage('First name required'),
  body('last_name').trim().notEmpty().withMessage('Last name required'),
];

const loginRules = [
  body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required'),
];

/* ── Order validators ────────────────────────── */
const createOrderRules = [
  body('customer.first_name').trim().notEmpty().withMessage('First name required'),
  body('customer.phone').trim().notEmpty().withMessage('Phone required'),
  body('shipping_address').trim().notEmpty().withMessage('Shipping address required'),
  body('city').trim().notEmpty().withMessage('City required'),
  body('pin').trim().isLength({ min: 6, max: 6 }).isNumeric().withMessage('Valid 6-digit PIN required'),
  body('items').isArray({ min: 1 }).withMessage('At least one item required'),
  body('items.*.product_id').isInt({ min: 1 }).withMessage('Valid product_id required'),
  body('items.*.quantity').isInt({ min: 1 }).withMessage('Quantity must be at least 1'),
  body('payment_method')
    .isIn(['credit_card', 'upi', 'net_banking', 'cash_on_delivery', 'emi'])
    .withMessage('Invalid payment method'),
];

/* ── Product validators ──────────────────────── */
const createProductRules = [
  body('name').trim().notEmpty().withMessage('Product name required'),
  body('price').isFloat({ min: 0 }).withMessage('Valid price required'),
  body('category_id').isInt({ min: 1 }).withMessage('Valid category_id required'),
  body('stock_quantity').optional().isInt({ min: 0 }).withMessage('Stock must be 0 or more'),
  body('mrp').optional().isFloat({ min: 0 }).withMessage('Valid MRP required'),
  body('badge').optional()
    .isIn(['deal', 'new', 'hot', 'bestseller']).withMessage('Invalid badge'),
];

/* ── Query validators ────────────────────────── */
const paginationRules = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be 1–100'),
];

module.exports = {
  validate,
  signupRules,
  loginRules,
  createOrderRules,
  createProductRules,
  paginationRules,
};

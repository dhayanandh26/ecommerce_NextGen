/**
 * Global error handling middleware
 */

const notFound = (req, res, next) => {
  const err = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  err.statusCode = 404;
  next(err);
};

const errorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || err.status || 500;

  // Log error in development
  if (process.env.NODE_ENV !== 'production') {
    console.error(`[${new Date().toISOString()}] ${err.stack || err.message}`);
  }

  // Supabase error format
  if (err.code && err.message && err.details !== undefined) {
    return res.status(400).json({
      success: false,
      error  : err.message,
      details: err.details,
      hint   : err.hint || null,
    });
  }

  res.status(statusCode).json({
    success   : false,
    error     : err.message || 'Internal Server Error',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
};

/**
 * Async route wrapper — eliminates try/catch boilerplate
 * Usage: router.get('/', asyncHandler(async (req, res) => { ... }))
 */
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { notFound, errorHandler, asyncHandler };
